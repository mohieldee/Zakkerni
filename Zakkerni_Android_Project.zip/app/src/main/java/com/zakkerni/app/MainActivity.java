package com.zakkerni.app;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.view.View;
import android.os.Build;
import android.content.pm.ActivityInfo;
public class MainActivity extends Activity {
  @Override public void onCreate(Bundle b) {
    super.onCreate(b);
    getWindow().setStatusBarColor(android.graphics.Color.rgb(2,44,34));
    getWindow().setNavigationBarColor(android.graphics.Color.rgb(2,44,34));
    WebView w = new WebView(this);
    w.setBackgroundColor(android.graphics.Color.rgb(246,245,238));
    WebSettings s = w.getSettings();
    s.setJavaScriptEnabled(true);
    s.setDomStorageEnabled(true);
    s.setMediaPlaybackRequiresUserGesture(true);
    s.setAllowFileAccess(true);
    s.setAllowContentAccess(true);
    w.setWebViewClient(new WebViewClient());
    w.setWebChromeClient(new WebChromeClient());
    w.loadUrl("file:///android_asset/index.html");
    setContentView(w);
  }
  @Override public void onBackPressed() { super.onBackPressed(); }
}